package com.example.viewfinal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;


public class CustomView extends View {

    private Rect rectangle1;
    private Rect rectangle2;
    private Rect rectangle3;
    private Rect rectangle4;
    private Rect rectangle5;
    private Rect rectangle6;
    private Rect rectangle7;
    private Rect rectangle8;


    private Paint paint;


    public CustomView(Context context) {
        super( context );
        int a = 1250;
        int a2 = 350;
        int a3 = 200;
        int a4 = 500;

        // create a rectangle that we'll draw later
        rectangle1 = new Rect( a, a2, a3, a4 );
        rectangle2 = new Rect( 1250, 550, 200, 700 );

        rectangle3 = new Rect( 1250, 850, 200, 1000 );
        rectangle4 = new Rect( 1250, 1050, 200, 1200 );

        rectangle5 = new Rect( 1250, 1350, 200, 1500 );
        rectangle6 = new Rect( 1250, 1550, 200, 1700 );

        rectangle7 = new Rect( 1250, 1850, 200, 2000 );
        rectangle8 = new Rect( 1250, 2050, 200, 2200 );


        // create the Paint and set its color
        paint = new Paint();
        paint.setColor( Color.rgb( 210,232,12 ) );

        //create the coordinate and set its default


    }


    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor( Color.argb( 255, 73, 147, 30 ) );
        canvas.drawRect( rectangle1, paint );
        canvas.drawRect( rectangle2, paint );

        canvas.drawRect( rectangle3, paint );
        canvas.drawRect( rectangle4, paint );

        canvas.drawRect( rectangle5, paint );
        canvas.drawRect( rectangle6, paint );

        canvas.drawRect( rectangle7, paint );
        canvas.drawRect( rectangle8, paint );

        Paint paint = new Paint();
        //paint.setColor(Color.WHITE);
        //paint.setStyle( Paint.Style.FILL);
        //canvas.drawPaint(paint);

        //paint.setColor(android.R.color.black);
        paint.setTextSize( 80 );
        canvas.drawText("Game 1",10,300, paint);
        canvas.drawText( "Player 1", 550, 450, paint );
        canvas.drawText("Player 2",550, 650, paint);

        canvas.drawText("Game 2",10,800, paint );
        canvas.drawText("Player 3",550, 950, paint);
        canvas.drawText("Player 4",550, 1150, paint);

        canvas.drawText("Game 3",10,1300, paint );
        canvas.drawText("Player 5",550, 1450, paint);
        canvas.drawText("Player 6",550, 1650, paint);

        canvas.drawText("Game 4",10,1800, paint );
        canvas.drawText("Player 7",550, 1950, paint);
        canvas.drawText("Player 8",550, 2150, paint);


    }

}






